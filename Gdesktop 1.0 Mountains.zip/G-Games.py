import tkinter as tk
import subprocess

window = tk.Tk()
window.title("G-Games")
window.geometry("250x200")

def dosbox():
    dosboxsh='dosbox'
    subprocess.Popen(dosboxsh , shell=True)
    
def redream():
    redreamsh='cd redream && ./redream'
    subprocess.Popen(redreamsh , shell=True)
def openttd():
    openttdsh='openttd'
    subprocess.Popen(openttdsh , shell=True)

dosbox = tk.Button(window, text="DOSBox", command=dosbox)
dosbox.grid(row=0, column=0)

redream = tk.Button(window, text="Redream", command=redream)
redream.grid(row=0, column=1)

openttd = tk.Button(window, text="OpenTTD", command=openttd)
openttd.grid(row=0, column=2)

window.mainloop()