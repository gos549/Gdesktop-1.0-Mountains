import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
window.title("Home")
window.geometry("440x110")

def save_file_saldo():
   
    tekst = saldo_t.get()
    with open("saldo.txt", "w") as plik:
        plik.write(tekst)
    messagebox.showinfo("Sukces", "Saldo Zapisane")
def save_file_wydatki():
   
    tekst = wydatki_t.get()
    with open("wydatki.txt", "w") as plik:
        plik.write(tekst)
    messagebox.showinfo("Sukces", "Wydaki Zapisane")
def save_file_oszczednosci():
   
    tekst = oszczednosci_t.get()
    with open("oszczednosci.txt", "w") as plik:
        plik.write(tekst)
    messagebox.showinfo("Sukces", "Oszczednosci Zapisane")

def load_file_saldo():
   
    try:
        with open('saldo.txt', 'r') as f:
            zawartosc = f.read()
            saldo_t.delete(0, tk.END) 
            saldo_t.insert(0, zawartosc)  
    except FileNotFoundError:
        pass
    
def load_file_oszczednosci():
   
    try:
        with open('oszczednosci.txt', 'r') as f:
            zawartosc = f.read()
            oszczednosci_t.delete(0, tk.END) 
            oszczednosci_t.insert(0, zawartosc)  
    except FileNotFoundError:
        pass
    
def load_file_wydatki():
   
    try:
        with open('wydatki.txt', 'r') as f:
            zawartosc = f.read()
            wydatki_t.delete(0, tk.END) 
            wydatki_t.insert(0, zawartosc)  
    except FileNotFoundError:
        pass
    
save_button_saldo = tk.Button(window, text="Zapisz Saldo", command=save_file_saldo)
save_button_saldo.grid(row=0, column=0)

save_button_wydatki = tk.Button(window, text="Zapisz Wydatki", command=save_file_wydatki)
save_button_wydatki.grid(row=1, column=0)

save_button_oszczednosci = tk.Button(window, text="Zapisz Oszczędności", command=save_file_oszczednosci)
save_button_oszczednosci.grid(row=2, column=0)

saldo = tk.Label (window, text= "saldo: ")
wydatki = tk.Label (window, text= "wydatki: ")
oszczednosci = tk.Label (window, text= "oszczędności: ")

saldo_t = tk.Entry(window)
wydatki_t = tk.Entry(window)
oszczednosci_t = tk.Entry(window)

saldo_t.grid(row=0, column=2)
wydatki_t.grid(row=1, column=2)
oszczednosci_t.grid(row=2, column=2)

saldo.grid(row=0, column=1)
wydatki.grid(row=1, column=1)
oszczednosci.grid(row=2, column=1)


load_file_saldo()
load_file_wydatki()
load_file_oszczednosci()

window.mainloop()