import tkinter as tk
from tkinter import messagebox
import os

def save_file():
    text = textbox.get("1.0", tk.END).strip()
    
    if not text:
        messagebox.showwarning("BŁĄD" "PUSTY PLIK")
        return
        
    try:
        with open("zapis.txt", "w", encoding="UTF-8") as plik:
            plik.write(text)
        messagebox.showinfo("SUKCES", f"PLIK ZAPISANY")
    except Exception as e:
        messagebox.showerror("BŁĄD",F"BŁĄD ZAPISU\n{str(e)}")
def load_file():
    
    sciezka = 'zapis.txt'
    try:
        with open(sciezka, 'r', encoding='utf-8') as plik:
            zawartosc = plik.read()
            textbox.insert(tk.END, zawartosc)  
    except FileNotFoundError:
        textbox.insert(tk.END, "Plik nie został znaleziony.")
            
window = tk.Tk()
window.title("Notes")
window.geometry("220x380")

save_button = tk.Button(window, text="ZAPISZ", command=save_file)
save_button.pack()

textbox = tk.Text(window)
textbox.pack()

window.after(0, load_file)
window.mainloop()
