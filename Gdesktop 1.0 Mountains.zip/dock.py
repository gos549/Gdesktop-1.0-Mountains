import tkinter as tk
import subprocess

window = tk.Tk()
window.title("G-OS")
window.geometry("440x40")

def Notes():
    Notes_url='python3 Notes.py'
    subprocess.Popen(Notes_url, shell=True)
def pliki():
    thunar='thunar'
    subprocess.Popen(thunar , shell=True)
def home():
    homepy='python3 Home.py'
    subprocess.Popen(homepy , shell=True)
def wylacz():
    wylaczpy='sudo shutdown now'
    subprocess.Popen(wylaczpy , shell=True)

def start():
    startpy='python3 Start.py'
    subprocess.Popen(startpy, shell=True)
    
def elisa():
    startpy='python3 ElisaModel.py'
    subprocess.Popen(startpy, shell=True)

start = tk.Button(window, text="Start", command=start)
start.grid(row=0, column=0)

program1 = tk.Button(window, text="Pliki", command=pliki)
program1.grid(row=0, column=1)

program2 = tk.Button(window, text="Notes", command=Notes)
program2.grid(row=0, column=2)


program3 = tk.Button(window, text="          ELISA          ", command=elisa)
program3.grid(row=0, column=4)

program4 = tk.Button(window, text="Home", command=home)
program4.grid(row=0, column=5)

quit_computer = tk.Button(window, text="Wyłącz", command=wylacz)
quit_computer.grid(row=0, column=6)

window.mainloop()