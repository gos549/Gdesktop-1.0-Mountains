import tkinter as tk
import subprocess

window = tk.Tk()
window.title("")
window.geometry("100x310")


def chrome():
    chromesh='chromium'
    subprocess.Popen(chromesh , shell=True)
def thonny():
    thonnysh='thonny'
    subprocess.Popen(thonnysh , shell=True)
def ggames():
    ggamessh='python3 G-Games.py'
    subprocess.Popen(ggamessh , shell=True)
    
def kalkulator():
    kalkulatorsh='galculator'
    subprocess.Popen(kalkulatorsh , shell=True)
def terminal():
    terminalsh='xfce4-terminal'
    subprocess.Popen(terminalsh , shell=True)
def ustawienia():
    ustawieniash='xfce4-settings-manager'
    subprocess.Popen(ustawieniash , shell=True)
    
def vlc():
    vlcsh='vlc'
    subprocess.Popen(vlcsh , shell=True)
def simengine():
    simenginesh='cd SimEngine && python3 simengine.py'
    subprocess.Popen(simenginesh , shell=True)
def mytv():
    mytvsh='cd MyTv && python3 MyTv.py'
    subprocess.Popen(mytvsh , shell=True)
chrome = tk.Button(window, text="Chrome", command=chrome)
chrome.grid(row=0, column=0)

vlc = tk.Button(window, text="Vlc", command=vlc)
vlc.grid(row=1, column=0)

mytv = tk.Button(window, text="MyTv", command=mytv)
mytv.grid(row=2, column=0)

ggames = tk.Button(window, text="G-Games", command=ggames)
ggames.grid(row=3, column=0)

thonny = tk.Button(window, text="Thonny", command=thonny)
thonny.grid(row=4, column=0)

simengine = tk.Button(window, text="Sim Engine", command=simengine)
simengine.grid(row=5, column=0)


kalkulator = tk.Button(window, text="Kalkulator", command=kalkulator)
kalkulator.grid(row=6, column=0)

terminal = tk.Button(window, text="Terminal", command=terminal)
terminal.grid(row=7, column=0) 

ustawienia = tk.Button(window, text="Ustawienia", command=ustawienia)
ustawienia.grid(row=8, column=0)

window.mainloop()