import tkinter as tk
import subprocess
import os

window = tk.Tk()
window.title("Install")
window.geometry("480x300")

def step1():
     try:
         
        subprocess.run(['sudo','apt-get', 'install', 'python3-pandas', 'python3-sklearn'], check=True)
        status_label.config(text="Pandas-sklearn zainstalowany pomyślnie.", fg="green")
     except subprocess.CalledProcessError:
        status_label.config(text="Wystąpił błąd podczas instalacji.", fg="red")
def step2():
     try:
         
        subprocess.run(['sudo','apt-get', 'install', 'python3-numpy'], check=True)
        status_label.config(text="Numpy zainstalowany pomyślnie.", fg="green")
     except subprocess.CalledProcessError:
        status_label.config(text="Wystąpił błąd podczas instalacji.", fg="red")
def step3():
     try:
         
        subprocess.run(['sudo','apt-get', 'install', 'python3-pil'], check=True)
        status_label.config(text="PIL zainstalowany pomyślnie.", fg="green")
     except subprocess.CalledProcessError:
        status_label.config(text="Wystąpił błąd podczas instalacji.", fg="red")
def step4():
     try:
         
        subprocess.run(['sudo','apt-get', 'install', 'dosbox', 'vlc'], check=True)
        status_label.config(text="Dosbox-Vlc zainstalowany pomyślnie.", fg="green")
     except subprocess.CalledProcessError:
        status_label.config(text="Wystąpił błąd podczas instalacji.", fg="red")
        
info = tk.Label(text="*Instalacja Bibliotek")
info.place(x=30, y=30)
info = tk.Label(text="*Instalacja Programów")
info.place(x=30, y=50)
info = tk.Label(text="*Końcowe Ustawienia Systemowe")
info.place(x=30, y=70)
info = tk.Label(text="*Gdesktop 2.0 Sky")
info.place(x=30, y=120)

status_label = tk.Label(window, text="")
status_label.place(x=30, y=140)

install_pandas = tk.Button(text="Step 1", command=step1)
install_pandas.place(x=10, y=230)

install_numpy = tk.Button(text="Step 2", command=step2)
install_numpy.place(x=80, y=230)

install_pil = tk.Button(text="Step 3", command=step3)
install_pil.place(x=150, y=230)

install_programs = tk.Button(text="Step 4", command=step4)
install_programs.place(x=220, y=230)


window.mainloop()