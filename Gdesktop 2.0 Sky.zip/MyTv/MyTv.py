import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image
import subprocess

pictures = ['logo.png', 'logo2.png', 'logo3.png']

def channel1():
    channel1vlc = 'vlc channel1.m3u'
    subprocess.Popen(channel1vlc, shell=True)
def channel2():
    channel2vlc = 'vlc channel2.m3u'
    subprocess.Popen(channel2vlc, shell=True)
def channel3():
    channel3vlc = 'vlc channel3.m3u'
    subprocess.Popen(channel3vlc, shell=True)
    
class MyTv:
    def __init__(self, window):
        self.window = window
        self.window.title("MyTv")
        self.window.geometry("900x400")
        self.window.configure(bg='#242222')
       
        self.y_position = 10 
        self.load_images()

    def load_images(self):
        for index, picture in enumerate(pictures):
            try:
                
                img = Image.open(picture)
                img = img.resize((300, 100), Image.ANTIALIAS)
                img_tk = ImageTk.PhotoImage(img)

                
                image_label = tk.Label(self.window, image=img_tk)
                image_label.image = img_tk 
                image_label.place(x=10, y=self.y_position)

               
                channel_info_label = tk.Label(self.window, text=f"TU MOŻESZ WPISAĆ OPIS KANAŁU LUB CO JEST ZAWARTE NA LIŚCIE M3U")
                channel_info_label.place(x=320, y=10)
                channel_info_label.configure(bg='#242222', fg='white')
                
                channel_info_label2 = tk.Label(self.window, text=f"ZMIENIĆ GRAFIKI NA WŁASNE")
                channel_info_label2.place(x=320, y=140)
                channel_info_label2.configure(bg='#242222', fg='white')
                
                channel_info_label3 = tk.Label(self.window, text=f"WERSJA PROGRAMU 1.0")
                channel_info_label3.place(x=320, y=270)
                channel_info_label3.configure(bg='#242222', fg='white')
                
              
                play_button = tk.Button(self.window, text="Play Channel", command=channel1)
                play_button.place(x=780, y=80)
                
                play_button2 = tk.Button(self.window, text="Play Channel", command=channel2)
                play_button2.place(x=780, y=220)
                
                play_button3 = tk.Button(self.window, text="Play Channel", command=channel3)
                play_button3.place(x=780, y=340)
                
                self.y_position += 130

            except Exception as e:
                messagebox.showerror("Błąd", f"Wystąpił błąd podczas ładowania obrazu: {str(e)}")

    def play_channel(self, channel_id):
        messagebox.showinfo("Informacja", f"Playing Channel {channel_id + 1}")

if __name__ == "__main__":
    window = tk.Tk()
    app = MyTv(window)
    window.mainloop()
