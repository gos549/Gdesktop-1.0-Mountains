import tkinter as tk
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline



data = {
    'text': [
        'co to jest nauka',
        'co to jest fizyka',
        'co to jest geografia',
        'co to jest chemia',
        'co to jest matematyka',
        'co to jest elektronika',
        'co to jest elektryka',
        'co to jest kosmos',
        'platformy',
        'platformy streamingowe',
        'mega wciągające filmy',
        'youtube',
        'Liczby w systemie rzymskim do 3000',
        'Funkcje trygonometryczne w trójkącie prostokątnym',
        'Ostrosłup prawidłowy czworokątny',
        'Grenlandia okiem paleontologa',
        'jesteśmy świadkami kształtowania się nowej normy klimatycznej',
        'Kardiolog: mróz niebezpieczny dla serca',
        'Jama ustna a płuca: jak bakterie z zębów mogą wpływać na układ oddechowy?',
        'co to jest rezystancja',
        'co to jest prąd',
        'pomysł na walentynki',
        'pomysł na obiad',
        'makaron burrata składniki',
        'emulator',
        'kim jesteś, nazywasz, imię',
        'Emulator Android',
        'ciekawe miejsca w polsce na wakacje',
        'języki programowania',
        'polecane gry'
    ],
    'label': [
        'Nauka to zobiektywizowany, kulturowy proces dążenia do wiedzy o rzeczywistości, obejmujący systematyczne badania, odkrycia oraz ich wytwory.',
        'Fizyka to fundamentalna nauka przyrodnicza badająca właściwości materii, energii, przestrzeni, czasu oraz ich wzajemne oddziaływania, od cząstek elementarnych po cały Wszechświat.',
        'Geografia to nauka zajmująca się opisem powłok Ziemi, badaniem zjawisk zachodzących w środowisku przyrodniczym oraz analizą relacji między naturą a działalnością człowieka.',
        'Chemia – nauka przyrodnicza badająca naturę i właściwości substancji, a zwłaszcza przemiany zachodzące pomiędzy nimi.',
        'Matematyka to nauka o liczbach, strukturach, przestrzeni i zmianach, wykorzystująca logiczne rozumowanie do opisywania i rozwiązywania problemów, od abstrakcyjnych koncepcji po praktyczne zastosowania',
        'Elektronika to dziedzina nauki i techniki zajmująca się wytwarzaniem, przetwarzaniem oraz przesyłaniem informacji i energii za pomocą sygnałów elektrycznych (prądów, napięć) oraz pól elektromagnetycznych.',
        'Elektryka to dziedzina nauki i techniki zajmująca się badaniem, wytwarzaniem, przesyłaniem oraz praktycznym wykorzystaniem zjawisk związanych z prądem elektrycznym i polami elektrycznymi.',
        'Kosmos to ogół wszechświata, w tym cała materia, energia i przestrzeń pozaziemska, często rozumiany jako uporządkowana całość (z gr. kósmos – porządek, ład). Stanowi synonim Wszechświata, a w węższym znaczeniu oznacza przestrzeń poza atmosferą ziemską.',
        'Słowo "platformy" ma wiele znaczeń, odnosi się do butów na grubej podeszwie (np. botki, sneakersy), platform sprzedażowych w e-commerce (Allegro, Amazon) i streamingowych (Netflix, HBO Max), a także może oznaczać platformy technologiczne czy cyfrowe.',
        'Najpopularniejsze platformy streamingowe (VOD) w Polsce w 2026 roku to przede wszystkim Netflix, Max (dawniej HBO Max), Disney+, Amazon Prime Video oraz SkyShowtime. Oferują one dostęp do filmów, seriali i programów na żądanie, często w wysokiej jakości, przy zróżnicowanych cenach subskrypcji i dostępności na wielu urządzeniach.',
        'Skazani na Shawshank, The Shawshank Redemption,Zielona mila, The Green Mile,Nietykalni, Intouchables,Ojciec chrzestny, The Godfather,Dwunastu gniewnych ludzi.',
        'W YouTube możesz cieszyć się filmami i muzyką, które lubisz, przesyłać oryginalne treści i udostępniać je swoim bliskim, znajomym i całemu światu.',
        'Liczby w systemie rzymskim zapisujemy znakami I, V, X, L, C, D, M. Ich wartości to I = 1, V = 5, X = 10, L = 50, C = 100, D = 500, M = 1000',
        'sin α = przyprostokątna naprzeciw α/ przeciwprostokątka   cos α = przyprostokątna przy α/ przeciwprostokątna',
        'Ostrosłup prawidłowy czworokątny ma w podstawie kwadrat. Wysokość ostrosłupa pada na środek jego podstawy. Ściany boczne ostrosłupa to cztery przystające trójkąty równoramienne.',
        'Na Grenlandii nadal są miejsca, a nawet całe rejony, gdzie stopy nie postawił dotąd żaden naukowiec. Paleontolog i kierownik wypraw dr Grzegorz Niedźwiedzki przeczuwa, że w kolejnych latach właśnie na tej wyspie pojawi się sporo „naukowych fajerwerków” z wiedzą zmieniającą podręczniki.',
        '2025 był trzecim najcieplejszym rokiem w historii pomiarów. Można uznać, że jesteśmy świadkami kształtowania się nowej normy klimatycznej, w której globalna temperatura utrzymuje się już blisko 1,5 st. C powyżej wartości w epoce preindustrialnej ',
        'Niskie temperatury nasilają zaburzenia układu krążenia, zwłaszcza u osób z chorobami serca – ostrzegł dr hab. Adam Janas, kardiolog Grupy American Heart of Poland. Dodał, że wysiłek w mroźne dni zwiększa ryzyko zawału serca.W komunikacie Grupy American Heart of Poland (Grupa AHP) przypomniano, że liczne badania potwierdzają negatywny wpływ silnych mrozów na serce.',
        'W świetle dostępnych danych najbardziej istotnymi klinicznie elementami stanu jamy ustnej, które mogą modulować ryzyko infekcji dolnych dróg oddechowych, pozostają przede wszystkim choroby przyzębia oraz obecność rozbudowanego biofilmu bakteryjnego',
        'Rezystancja (opór elektryczny) to wielkość fizyczna określająca zdolność materiału do przeciwstawiania się przepływowi prądu stałego, oznaczana symbolem \(R\) i mierzona w omach (\(\Omega \)). Zgodnie z prawem Ohma (\(R=U/I\)), im wyższa rezystancja, tym mniejszy prąd płynie przy danym napięciu. Zależy od rodzaju materiału, temperatury oraz geometrii przewodu.',
        'Prąd elektryczny to uporządkowany ruch ładunków elektrycznych (zazwyczaj elektronów) w przewodniku, wywołany różnicą potencjałów, czyli napięciem. Płynie od wyższego do niższego potencjału, a jego natężenie określa ilość ładunku przepływającego przez poprzeczny przekrój przewodnika w jednostce czasu. Wyróżniamy prąd stały (DC) i zmienny (AC).',
        'Pomysły na Walentynki obejmują romantyczne wyjazdy (domek w górach), relaks w SPA dla par, aktywności jak kurs tańca lub warsztaty kulinarne, oraz klasyczne wyjścia do teatru czy na kolację. W domu sprawdzą się domowe SPA, tematyczna kolacja z wyzwaniem kulinarnym, wieczór filmowy lub personalizowane prezenty, takie jak zdjęcia, albumy czy kupony walentynkowe.',
        'Spaghetti z mięsem, Makaron ze szpinakiem i tuńczykiem, Makaron z kurczakiem i pieczarkami, Makaron z sosem pomidorowym i tuńczykiem, Pancakes z grysiku, Risotto ze szpinakiem i zielonym groszkiem, Gulasz z indykiem i kukurydzą, Kładzione kluseczki bananowe.',
        'składniki: burrata 2szt. , ząbek czosku 2szt. , parmezan 30g, oliwa z oliwek 1 łyżka, sól, pieprz czarny, makaron rigatoni 250g',
        'Emulator – program komputerowy (czasem wraz z koniecznym sprzętem), który uruchomiony w danym systemie komputerowym duplikuje funkcje innego systemu komputerowego. Pierwszy system nazywany jest gospodarzem (ang. host), a drugi gościem (ang. guest). Mówimy, że drugi system jest emulowany przez pierwszy.',
        'Jestem Elisa wirtualny assystent',
        'BlueStacks, LDPlayer, GameLoop, Android Studio, NoxPlayer, Genymotion',
        'Suwalski Park Krajobrazowy, Lublin, Park Narodowy Ujście Warty, Supraśl, Bieszczady, Biecz, Dolina Pałaców i Ogrodów, Góry Stołowe, Kazimierz Dolny, Jura Krakowsko Częstochowska, Kraków, Karkonosze, Pieniny, Słowiński Park Narodowy.',
        'Python,JavaScript,Java,C++,C#,Assembler',
        'Command & Conquer: Red Alert,Commandos: Behind Enemy Lines,Championship Manager 03/04,GTA Vice City,Soldier of Fortune,Metal Gear Solid,Max Payne,Warcraft 2,Starcraft,Fable'
    ]
}

df = pd.DataFrame(data)
model = make_pipeline(CountVectorizer(), MultinomialNB())
model.fit(df['text'], df['label'])

def predict_label():
    input_text = entry.get()
    prediction = model.predict([input_text])
    result_var.set(prediction[0])

window = tk.Tk()
window.title("Elisa")

entry = tk.Entry(window, width=50)
entry.pack(pady=10)

button = tk.Button(window, text="WYŚLIJ", command=predict_label)
button.pack(pady=10)

result_var = tk.StringVar()
result_entry = tk.Entry(window, textvariable=result_var, width=50)
result_entry.pack(pady=10)


window.mainloop()