import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image
import os

dialog_files = ['dialog0.txt', 'dialog1.txt']
pictures = ['picture0.png', 'picture1.png']

class GameApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Game")
        self.root.geometry("800x600")
        self.root.configure(bg='#242222')

        self.current_dialog_index = 0
        self.current_picture_index = 0

        # Ustawienie pierwszego obrazu
        self.image_label = tk.Label(self.root)
        self.image_label.place(x=50, y=45)
        self.load_picture()

        # Etykieta do wyświetlania dialogu
        self.dialog = tk.Label(self.root, text="Sim Engine", bg='#242222', fg='white')
        self.dialog.place(x=50, y=500)

        # Przycisk do przejścia do następnego dialogu
        self.nextdialog = tk.Button(self.root, text="->", command=self.load_file, bg='#242222', fg='white')
        self.nextdialog.place(x=712, y=550)

    def load_picture(self):
        try:
            # Ładujemy nowy obraz
            picture = Image.open(pictures[self.current_picture_index])
            img = picture.resize((700, 450), Image.ANTIALIAS)
            img_tk = ImageTk.PhotoImage(img)

            # Aktualizujemy etykietę obrazu
            self.image_label.config(image=img_tk)
            self.image_label.image = img_tk  # Zachowaj odniesienie do zdjęcia

            # Zwiększamy indeks obrazu po załadowaniu
            self.current_picture_index = (self.current_picture_index + 1) % len(pictures)

        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd podczas ładowania obrazu: {str(e)}")

    def load_file(self):
        try:
            with open(dialog_files[self.current_dialog_index], 'r', encoding='utf-8') as plik:
                zawartosc = plik.read()
                self.dialog.config(text=zawartosc)

                # Zwiększamy indeks dialogu
                self.current_dialog_index = (self.current_dialog_index + 1) % len(dialog_files)

                # Przeładuj obrazek po wczytaniu dialogu
                self.load_picture()

        except FileNotFoundError:
            self.dialog.config(text="Plik nie został znaleziony")
        except Exception as e:
            self.dialog.config(text=f"Wystąpił błąd: {str(e)}")

# Ustawienia interfejsu graficznego
if __name__ == "__main__":
    root = tk.Tk()
    app = GameApp(root)
    root.mainloop()

