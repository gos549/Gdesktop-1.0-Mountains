import tkinter as tk
from tkinter import messagebox
import os

def save_file():
    text = edit.get("1.0", tk.END).strip()
    
    if not text:
        messagebox.showwarning("BŁĄD" "PUSTY PLIK")
        return
        
    try:
        with open("game.py", "w", encoding="UTF-8") as plik:
            plik.write(text)
        messagebox.showinfo("SUKCES", f"PLIK ZAPISANY")
    except Exception as e:
        messagebox.showerror("BŁĄD",F"BŁĄD ZAPISU\n{str(e)}")

def load_file():
    url = 'game.py'
    try:
        with open(url, 'r', encoding='utf-8') as plik:
            zawartosc = plik.read()
            edit.insert(tk.END, zawartosc)
    except FileNotFoundError:
        edit.insert(tk.END, "Błąd plik nie wczytany")

editscript = tk.Tk()
editscript.title("EDIT SCRIPT")
editscript.geometry("670x300")

save_edit = tk.Button(text="Save", command=save_file)
save_edit.pack()

edit = tk.Text(editscript, height=30, width=60)
edit.pack()

editscript.after(0,load_file)
editscript.mainloop()
