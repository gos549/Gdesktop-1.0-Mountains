import tkinter as tk
from tkinter import messagebox
import subprocess

simengine = tk.Tk()
simengine.title("Sim Engine")
simengine.geometry("280x30")

def about_click():
    messagebox.showinfo("sim engine", f"alpha 0.0.1")

def editscript():
    edit_script_py='python3 script.py'
    subprocess.Popen(edit_script_py, shell=True)
def rungame():
    run_game_py='python3 game.py'
    subprocess.Popen(run_game_py, shell=True)

about = tk.Button(text="about", command=about_click)
about.grid(row=0, column=0)

edit_script = tk.Button(text="edit_script", command=editscript)
edit_script.grid(row=0, column=1)

run_game = tk.Button(text="run_game", command=rungame)
run_game.grid(row=0, column=2)

simengine.mainloop()
